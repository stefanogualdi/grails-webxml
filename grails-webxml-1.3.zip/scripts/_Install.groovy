ant.copy file:   "$webxmlPluginDir/src/samples/_WebXmlConfig.groovy",
         tofile: "$basedir/grails-app/conf/WebXmlConfig.groovy"
